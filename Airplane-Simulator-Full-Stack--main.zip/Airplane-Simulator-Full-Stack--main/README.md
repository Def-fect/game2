The full, working project is in the following folder: testing > frontend. The frontend folder in the testing folder contains the index.html file which by running the file in the liveserver opens up the game.
To run the game, first run the game server in the backend folder and after run the index.html file in the "testing" folder.
The serverside of the game uses various libraries so remember to update and/or download the ones you are missing.
